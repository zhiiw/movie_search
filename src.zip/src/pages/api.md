# Login
/api/login
# Register
/api/register

# Admin

/api/admin/movie/increase
/api/admin/movie/delete
/api/admin/movie/update
/api/admin/movie/create
/api/admin/movie/list

# User

/api/user/movie/list_part_movie
/api/user/movie/getMovie {GET :movieId}
/api/user/movie/star
/api/user/movie/review
/api/user/movie/search {GET :movieName}


